# RoundedTask

RoundedTask is a lightweight Windows taskbar shaping utility inspired by RoundedTB.

This version is intentionally conservative: it does not move the Windows taskbar, draw overlays, or patch Explorer. It only applies a rounded region to the real Windows taskbar and restores it on exit when configured.

## Goals

- Windows 11 friendly behavior
- Very low idle overhead
- Tray-first UI
- Safe restore on exit
- No Electron, no background services, no telemetry
- No fake overlay bars

## Build

This repository can be built with the .NET Framework compiler included with Windows:

```powershell
.\build.ps1
```

The executable is written to:

```text
bin\RoundedTask.exe
```

Recovery commands:

```powershell
.\bin\RoundedTask.exe --restore
.\bin\RoundedTask.exe --apply-once
```

## Current features

- Rounded corners for primary and secondary taskbars
- Layouts: full bar or center + system area
- Independent margins for left, top, right, and bottom
- Center width, center offset, and system area width controls
- System right inset control for trimming the clock/system island from the right side
- Live preview while changing settings
- Presets: Balanceado, Compacto, Flutuante, Pílula completa, Centro e sistema
- Automatic reapply after Explorer recreates the taskbar
- Optional restore on exit
- Optional startup registration in `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`

The `Centro e sistema` layout uses a real taskbar region with two visible areas. It does not create overlay bars, but anything outside those visible areas is clipped by Windows, so keep the center and system widths large enough to cover the buttons you need.

## Notes

No app that customizes the Windows shell can honestly guarantee "zero bugs" across every Windows 11 build, monitor layout, and Explorer update. RoundedTask is designed around safer primitives, minimal polling, and quick restore paths so failures are contained and reversible.
